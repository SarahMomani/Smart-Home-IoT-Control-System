import time
import requests
from datetime import datetime
import board
import adafruit_dht

apiKeyThingspeak = "K326H16HIZC50R8L"
theUrl = "https://api.thingspeak.com/update"
dht = adafruit_dht.DHT11(board.D4)
timeUpload = 20
print("Thing speak start to upload")

while True:
    timestamp = datetime.now().replace(microsecond=0).isoformat()
    try:
        temperature = dht.temperature
        humidity = dht.humidity
        if temperature is not None and humidity is not None:
            payload = {
                "api_key": apiKeyThingspeak,
                "field1": round(temperature, 1),
                "field2": round(humidity, 1)
            }
            response = requests.get(
                theUrl,
                params=payload,
                timeout=10
            )
            if response.status_code == 200 and response.text.strip() != "0":
                print(
                    f"{timestamp} | Uploaded "
                    f"T={temperature:.1f}°C  RH={humidity:.1f}%  "
                    f"EntryID={response.text.strip()}"
                )
            else:
                print(
                    f"{timestamp} | Upload failed "
                    f"HTTP={response.status_code} "
                    f"Response={response.text.strip()}"
                )
        else:
            print(f"{timestamp} | sensor read returned None")
    except RuntimeError:
        print(f"{timestamp} | DHT11 read error")
    except requests.RequestException as e:
        print(f"{timestamp} | network error: {e}")

    time.sleep(timeUpload)
