import RPi.GPIO as GPIO
import time
import paho.mqtt.client as mqtt

safeCode = "#2468#"
ledPin = 17
servoePin = 18
fanPin = 23
rows = [5, 6, 13, 19]
cols = [12, 16, 20, 21]
keypad = [
    ['1', '2', '3', 'A'],
    ['4', '5', '6', 'B'],
    ['7', '8', '9', 'C'],
    ['*', '0', '#', 'D']
]
brokerIP = "localhost"
Brokerport = 1883
topicType = "gptpros/rama/safe_mode"

GPIO.setmode(GPIO.BCM)
GPIO.setup(ledPin, GPIO.OUT)
led_pwm = GPIO.PWM(ledPin, 100)
led_pwm.start(0)
GPIO.setup(servoePin, GPIO.OUT)
servo_pwm = GPIO.PWM(servoePin, 50)
servo_pwm.start(0)
GPIO.setup(fanPin, GPIO.OUT)
GPIO.output(fanPin, GPIO.LOW)

for r in rows:
    GPIO.setup(r, GPIO.OUT)
    GPIO.output(r, GPIO.HIGH)

for c in cols:
    GPIO.setup(c, GPIO.IN, pull_up_down=GPIO.PUD_UP)

def angle_to_duty(angle: float) -> float:
    return 2.5 + (angle / 180.0) * 10.0

def set_servo(angle: float):
    servo_pwm.ChangeDutyCycle(angle_to_duty(angle))
    time.sleep(0.4)
    servo_pwm.ChangeDutyCycle(0)

def normal_mode():
    print("normal mode the LED on, servo 90°, fan on")
    led_pwm.ChangeDutyCycle(100)
    set_servo(90)
    GPIO.output(fanPin, GPIO.HIGH)

def safe_mode():
    print("safe mode the LED off, servo 0°, fan off")
    led_pwm.ChangeDutyCycle(0)
    set_servo(0)
    GPIO.output(fanPin, GPIO.LOW)

def scan_keypad():
    for i, r in enumerate(rows):
        GPIO.output(r, GPIO.LOW)
        for j, c in enumerate(cols):
            if GPIO.input(c) == GPIO.LOW:
                GPIO.output(r, GPIO.HIGH)
                return keypad[i][j]
        GPIO.output(r, GPIO.HIGH)
    return None

code_buffer = ""
last_key = None
safe_requested = False

def request_safe_mode(reason: str):
    global safe_requested
    print(f"safe mode {reason}")
    safe_requested = True

def on_connect(client, userdata, flags, rc):
    print("MQTT connected ", rc)
    if rc == 0:
        client.subscribe(topicType)
        print("Subscribed to:", topicType)
    else:
        print("MQTT connect failed")

def on_message(client, userdata, msg):
    payload = msg.payload.decode(errors="ignore").strip()
    print(f"MQTT message on {msg.topic}: {payload}")
    if payload == safeCode or safeCode in payload:
        request_safe_mode("MQTT")

def on_disconnect(client, userdata, rc):
    print("MQTT disconnected ", rc)

client = mqtt.Client(protocol=mqtt.MQTTv311)
client.on_connect = on_connect
client.on_message = on_message
client.on_disconnect = on_disconnect

try:
    normal_mode()
    print(f"Connecting to MQTT broker {brokerIP}:{Brokerport} ...")
    client.connect(brokerIP, Brokerport, keepalive=60)
    client.loop_start()
    print("start")
    print(f"Publish {safeCode} to topic: {topicType}")

    while True:
        if safe_requested:
            safe_mode()
            safe_requested = False

        key = scan_keypad()
        if key is not None and key != last_key:
            print("the key:", key)
            if key.isdigit() or key == '#':
                code_buffer += key
                print("Local buffer:", code_buffer[-10:])
                if len(code_buffer) > 10:
                    code_buffer = code_buffer[-10:]
                if code_buffer.endswith(safeCode):
                    request_safe_mode("keypad")
                    code_buffer = ""
            if key == '*':
                code_buffer = ""
            last_key = key
            time.sleep(0.2)

        if key is None:
            last_key = None

        time.sleep(0.05)

except KeyboardInterrupt:
    print("stop")

finally:
    try:
        client.loop_stop()
        client.disconnect()
    except:
        pass
    try:
        led_pwm.ChangeDutyCycle(0)
        servo_pwm.ChangeDutyCycle(0)
        time.sleep(0.1)
        led_pwm.stop()
        servo_pwm.stop()
    except:
        pass
    GPIO.cleanup()
