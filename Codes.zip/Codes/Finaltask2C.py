import RPi.GPIO as GPIO
import time
from datetime import datetime
import board
import adafruit_dht

GPIO.setmode(GPIO.BCM)
servoPin = 18
GPIO.setup(servoPin, GPIO.OUT)
servoPwm = GPIO.PWM(servoPin, 50)
servoPwm.start(0)
dht = adafruit_dht.DHT11(board.D4)
last_dht_time = 0
rows = [5, 6, 13, 19]
cols = [12, 16, 20, 21]
keypad = [
    ['1', '2', '3', 'A'],
    ['4', '5', '6', 'B'],
    ['7', '8', '9', 'C'],
    ['*', '0', '#', 'D']
]

for r in rows:
    GPIO.setup(r, GPIO.OUT)
    GPIO.output(r, GPIO.HIGH)

for c in cols:
    GPIO.setup(c, GPIO.IN, pull_up_down=GPIO.PUD_UP)

def set_servo(angle):
    duty = 2 + (angle / 18)
    servoPwm.ChangeDutyCycle(duty)
    time.sleep(0.4)
    servoPwm.ChangeDutyCycle(0)

def scan_keypad():
    for i, r in enumerate(rows):
        GPIO.output(r, GPIO.LOW)
        for j, c in enumerate(cols):
            if GPIO.input(c) == GPIO.LOW:
                GPIO.output(r, GPIO.HIGH)
                return keypad[i][j]
        GPIO.output(r, GPIO.HIGH)
    return None

last_key = None

try:
    while True:
        if time.time() - last_dht_time >= 2:
            try:
                temperature = dht.temperature
                humidity = dht.humidity
                timestamp = datetime.now().replace(microsecond=0).isoformat()
                print(f"{timestamp} | T={temperature}°C | RH={humidity}%")
                if temperature > 28:
                    print("Rule is that the temperature up than 28 is a open vent")
                    set_servo(90)
                elif temperature < 22:
                    print("Rule us that the temperature low than 22 is a close vent")
                    set_servo(0)
            except RuntimeError:
                pass
            last_dht_time = time.time()

        key = scan_keypad()
        if key is not None and key != last_key:
            print("the key:", key)
            if key == '0':
                print("Key 0 is a open vent")
                set_servo(90)
            elif key == '1':
                print("Key 1 is a close vent")
                set_servo(0)
            last_key = key

        if key is None:
            last_key = None

        time.sleep(0.05)

except KeyboardInterrupt:
    print("stop")

finally:
    servoPwm.stop()
    GPIO.cleanup()
