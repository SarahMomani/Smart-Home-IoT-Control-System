import time
from datetime import datetime
import board
import adafruit_dht
dht = adafruit_dht.DHT11(board.D4)
while True:
   try:
       tmp = dht.temperature
       hum = dht.humidity
       tmm = datetime.now().replace(microsecond=0).isoformat()
       print(f"{tmm} | T={tmp:.1f}°C | RH={hum:.1f}%")
   except RuntimeError:
       pass
   time.sleep(2)