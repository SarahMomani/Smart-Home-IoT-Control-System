import RPi.GPIO as GPIO
import paho.mqtt.client as mqtt
import time

GPIO.setmode(GPIO.BCM)
ledPin = 17
GPIO.setup(ledPin, GPIO.OUT)
ledPwm = GPIO.PWM(ledPin, 100)
ledPwm.start(0)
humHigh = 70
humLow = 60
broker = "broker.hivemq.com"
port = 1883
topicHum = "iot/room/humidity"

def on_connect(client, userdata, flags, rc):
    print("Connected to MQTT ", rc)
    client.subscribe(topicHum)
    print("Subscribed to topic:", topicHum)

def on_message(client, userdata, msg):
    try:
        humidity = float(msg.payload.decode().strip())
        print(f"Received humidity by MQTT: {humidity:.1f}%")
        if humidity > humHigh:
            ledPwm.ChangeDutyCycle(100)
            print("when the humidity high the light on")
        elif humidity < humLow:
            ledPwm.ChangeDutyCycle(0)
            print("when the humidity low the light off")
    except ValueError:
        print("No data")

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

try:
    client.connect(broker, port, 60)
    client.loop_forever()
except KeyboardInterrupt:
    print("stop")
finally:
    ledPwm.stop()
    GPIO.cleanup()
