import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)

Ledpin = 17
GPIO.setup(Ledpin, GPIO.OUT)
led_pwm = GPIO.PWM(Ledpin, 100)
led_pwm.start(0)

pinButon = 27
GPIO.setup(pinButon, GPIO.IN, pull_up_down=GPIO.PUD_UP)

row = [5, 6, 13, 19]
cols = [12, 16, 20, 21]
keypad = [
    ['1', '2', '3', 'A'],
    ['4', '5', '6', 'B'],
    ['7', '8', '9', 'C'],
    ['*', '0', '#', 'D']
]

for r in row:
    GPIO.setup(r, GPIO.OUT)
    GPIO.output(r, GPIO.HIGH)

for c in cols:
    GPIO.setup(c, GPIO.IN, pull_up_down=GPIO.PUD_UP)

led_state = False

print("Start")

def led_on():
    global led_state
    led_pwm.ChangeDutyCycle(100)
    led_state = True
    print("LED on")

def led_off():
    global led_state
    led_pwm.ChangeDutyCycle(0)
    led_state = False
    print("LED off")

def toggle_led():
    if led_state:
        led_off()
    else:
        led_on()

def read_keypad():
    for i, r in enumerate(row):
        GPIO.output(r, GPIO.LOW)
        for j, c in enumerate(cols):
            if GPIO.input(c) == GPIO.LOW:
                GPIO.output(r, GPIO.HIGH)
                return keypad[i][j]
        GPIO.output(r, GPIO.HIGH)
    return None

def button_pressed_callback(channel):
    toggle_led()

GPIO.add_event_detect(
    pinButon,
    GPIO.FALLING,
    callback=button_pressed_callback,
    bouncetime=300
)

try:
    while True:
        key = read_keypad()
        if key:
            print(f"Key pressed: {key}")
            if key == 'A':
                led_on()
            elif key == 'B':
                led_off()
            time.sleep(0.3)
        time.sleep(0.05)

except KeyboardInterrupt:
    print("stop")

finally:
    led_pwm.stop()
    GPIO.cleanup()
